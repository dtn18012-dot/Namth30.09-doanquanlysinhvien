import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SinhVienDAO {
    public List<Model.SinhVien> getAll(String keyword) throws SQLException {
        List<Model.SinhVien> list = new ArrayList<>();
        String sql = "SELECT MaSV, HoTen, NgaySinh, GioiTinh, Email, SoDienThoai, MaLop "
                   + "FROM sinh_vien "
                   + "WHERE (? = '' OR MaSV LIKE ? OR HoTen LIKE ? OR MaLop LIKE ?) "
                   + "ORDER BY MaSV";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String k = keyword == null ? "" : keyword.trim();
            ps.setString(1, k);
            ps.setString(2, "%" + k + "%");
            ps.setString(3, "%" + k + "%");
            ps.setString(4, "%" + k + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Model.SinhVien(
                        rs.getString("MaSV"),
                        rs.getString("HoTen"),
                        rs.getString("NgaySinh"),
                        rs.getString("GioiTinh"),
                        rs.getString("Email"),
                        rs.getString("SoDienThoai"),
                        rs.getString("MaLop")
                    ));
                }
            }
        }
        return list;
    }

    public boolean insert(Model.SinhVien sv) throws SQLException {
        String sql = "INSERT INTO sinh_vien(MaSV, HoTen, NgaySinh, GioiTinh, Email, SoDienThoai, MaLop) "
                   + "VALUES(?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, sv.maSV);
            ps.setString(2, sv.hoTen);
            ps.setString(3, sv.ngaySinh);
            ps.setString(4, sv.gioiTinh);
            ps.setString(5, sv.email);
            ps.setString(6, sv.soDienThoai);
            ps.setString(7, sv.maLop);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(Model.SinhVien sv) throws SQLException {
        String sql = "UPDATE sinh_vien SET HoTen = ?, NgaySinh = ?, GioiTinh = ?, "
                   + "Email = ?, SoDienThoai = ?, MaLop = ? WHERE MaSV = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, sv.hoTen);
            ps.setString(2, sv.ngaySinh);
            ps.setString(3, sv.gioiTinh);
            ps.setString(4, sv.email);
            ps.setString(5, sv.soDienThoai);
            ps.setString(6, sv.maLop);
            ps.setString(7, sv.maSV);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(String maSV) throws SQLException {
        String sql = "DELETE FROM sinh_vien WHERE MaSV = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maSV);
            return ps.executeUpdate() > 0;
        }
    }
}