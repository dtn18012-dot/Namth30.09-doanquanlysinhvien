import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String SERVER = "localhost";
    private static final String PORT = "1433";
    private static final String DATABASE = "qlsinhvien";

    public static Connection getConnection() throws SQLException {
        String url = "jdbc:sqlserver://" + SERVER + ":" + PORT + ";"
                   + "databaseName=" + DATABASE + ";"
                   + "integratedSecurity=true;"
                   + "encrypt=true;trustServerCertificate=true;";
        return DriverManager.getConnection(url);
    }
}