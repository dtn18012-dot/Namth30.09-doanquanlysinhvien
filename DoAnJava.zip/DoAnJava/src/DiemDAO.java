import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DiemDAO {
    public List<Model.Diem> getAll(String keyword) throws SQLException {
        List<Model.Diem> list = new ArrayList<>();
        String sql = "SELECT MaSV, MaMH, HocKy, Diem FROM diem "
                   + "WHERE (? = '' OR MaSV LIKE ? OR MaMH LIKE ? OR HocKy LIKE ?) "
                   + "ORDER BY MaSV, MaMH, HocKy";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String k = keyword == null ? "" : keyword.trim();
            ps.setString(1, k);
            ps.setString(2, "%" + k + "%");
            ps.setString(3, "%" + k + "%");
            ps.setString(4, "%" + k + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Model.Diem(
                        rs.getString("MaSV"),
                        rs.getString("MaMH"),
                        rs.getString("HocKy"),
                        rs.getDouble("Diem")
                    ));
                }
            }
        }
        return list;
    }

    public boolean insert(Model.Diem d) throws SQLException {
        String sql = "INSERT INTO diem(MaSV, MaMH, HocKy, Diem) VALUES(?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, d.maSV);
            ps.setString(2, d.maMH);
            ps.setString(3, d.hocKy);
            ps.setDouble(4, d.diemSo);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(Model.Diem d) throws SQLException {
        String sql = "UPDATE diem SET Diem = ? WHERE MaSV = ? AND MaMH = ? AND HocKy = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, d.diemSo);
            ps.setString(2, d.maSV);
            ps.setString(3, d.maMH);
            ps.setString(4, d.hocKy);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(String maSV, String maMH, String hocKy) throws SQLException {
        String sql = "DELETE FROM diem WHERE MaSV = ? AND MaMH = ? AND HocKy = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maSV);
            ps.setString(2, maMH);
            ps.setString(3, hocKy);
            return ps.executeUpdate() > 0;
        }
    }
}