import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;

public class MainFrame extends JFrame {
    private final LopDAO lopDAO = new LopDAO();
    private final SinhVienDAO svDAO = new SinhVienDAO();
    private final MonHocDAO mhDAO = new MonHocDAO();
    private final DiemDAO diemDAO = new DiemDAO();

    public MainFrame() {
        setTitle("Quản Lý Sinh Viên - SQL Server");
        setSize(980, 640);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Lớp", createLopPanel());
        tabs.addTab("Sinh Viên", createSinhVienPanel());
        tabs.addTab("Môn Học", createMonHocPanel());
        tabs.addTab("Điểm", createDiemPanel());

        add(tabs);
    }

    private void showError(Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    private void showInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }

    // ================= TAB LỚP =================
    private JPanel createLopPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JTextField txtSearch = new JTextField(20);
        JButton btnSearch = new JButton("Tìm");
        JButton btnReload = new JButton("Tải lại");
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Tìm lớp:"));
        top.add(txtSearch);
        top.add(btnSearch);
        top.add(btnReload);

        JTextField txtMaLop = new JTextField();
        JTextField txtTenLop = new JTextField();
        JTextField txtKhoaHoc = new JTextField();
        JTextField txtNganhHoc = new JTextField();
        JPanel form = new JPanel(new GridLayout(2, 4, 6, 6));
        form.add(new JLabel("Mã lớp:")); form.add(txtMaLop);
        form.add(new JLabel("Tên lớp:")); form.add(txtTenLop);
        form.add(new JLabel("Khóa học:")); form.add(txtKhoaHoc);
        form.add(new JLabel("Ngành học:")); form.add(txtNganhHoc);

        JButton btnAdd = new JButton("Thêm");
        JButton btnUpdate = new JButton("Sửa");
        JButton btnDelete = new JButton("Xóa");
        JButton btnClear = new JButton("Xóa trắng");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER));
        actions.add(btnAdd); actions.add(btnUpdate); actions.add(btnDelete); actions.add(btnClear);

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Mã lớp", "Tên lớp", "Khóa học", "Ngành học"}, 0
        );
        JTable table = new JTable(model);

        Runnable loadData = () -> {
            try {
                model.setRowCount(0);
                List<Model.Lop> list = lopDAO.getAll(txtSearch.getText());
                for (Model.Lop l : list) {
                    model.addRow(new Object[]{l.maLop, l.tenLop, l.khoaHoc, l.nganhHoc});
                }
            } catch (SQLException ex) {
                showError(ex);
            }
        };

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int r = table.getSelectedRow();
                if (r >= 0) {
                    txtMaLop.setText(val(model, r, 0));
                    txtTenLop.setText(val(model, r, 1));
                    txtKhoaHoc.setText(val(model, r, 2));
                    txtNganhHoc.setText(val(model, r, 3));
                }
            }
        });

        btnSearch.addActionListener(e -> loadData.run());
        btnReload.addActionListener(e -> { txtSearch.setText(""); loadData.run(); });
        btnClear.addActionListener(e -> {
            txtMaLop.setText(""); txtTenLop.setText(""); txtKhoaHoc.setText(""); txtNganhHoc.setText("");
        });

        btnAdd.addActionListener(e -> {
            try {
                Model.Lop l = new Model.Lop(
                    txtMaLop.getText().trim(), txtTenLop.getText().trim(),
                    txtKhoaHoc.getText().trim(), txtNganhHoc.getText().trim()
                );
                if (lopDAO.insert(l)) {
                    showInfo("Thêm lớp thành công");
                    loadData.run();
                }
            } catch (SQLException ex) { showError(ex); }
        });

        btnUpdate.addActionListener(e -> {
            try {
                Model.Lop l = new Model.Lop(
                    txtMaLop.getText().trim(), txtTenLop.getText().trim(),
                    txtKhoaHoc.getText().trim(), txtNganhHoc.getText().trim()
                );
                if (lopDAO.update(l)) {
                    showInfo("Sửa lớp thành công");
                    loadData.run();
                }
            } catch (SQLException ex) { showError(ex); }
        });

        btnDelete.addActionListener(e -> {
            try {
                if (lopDAO.delete(txtMaLop.getText().trim())) {
                    showInfo("Xóa lớp thành công");
                    loadData.run();
                }
            } catch (SQLException ex) { showError(ex); }
        });

        JPanel north = new JPanel(new BorderLayout(6, 6));
        north.add(top, BorderLayout.NORTH);
        north.add(form, BorderLayout.CENTER);
        north.add(actions, BorderLayout.SOUTH);

        panel.add(north, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        loadData.run();
        return panel;
    }

    // ================= TAB SINH VIÊN =================
    private JPanel createSinhVienPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JTextField txtSearch = new JTextField(20);
        JButton btnSearch = new JButton("Tìm");
        JButton btnReload = new JButton("Tải lại");
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Tìm SV:")); top.add(txtSearch); top.add(btnSearch); top.add(btnReload);

        JTextField txtMaSV = new JTextField();
        JTextField txtHoTen = new JTextField();
        JTextField txtNgaySinh = new JTextField();
        JComboBox<String> cbGioiTinh = new JComboBox<>(new String[]{"Nam", "Nữ"});
        JTextField txtEmail = new JTextField();
        JTextField txtSDT = new JTextField();
        JTextField txtMaLop = new JTextField();

        JPanel form = new JPanel(new GridLayout(4, 4, 6, 6));
        form.add(new JLabel("Mã SV:")); form.add(txtMaSV);
        form.add(new JLabel("Họ tên:")); form.add(txtHoTen);
        form.add(new JLabel("Ngày sinh (yyyy-MM-dd):")); form.add(txtNgaySinh);
        form.add(new JLabel("Giới tính:")); form.add(cbGioiTinh);
        form.add(new JLabel("Email:")); form.add(txtEmail);
        form.add(new JLabel("Số điện thoại:")); form.add(txtSDT);
        form.add(new JLabel("Mã lớp:")); form.add(txtMaLop);
        form.add(new JLabel("")); form.add(new JLabel(""));

        JButton btnAdd = new JButton("Thêm");
        JButton btnUpdate = new JButton("Sửa");
        JButton btnDelete = new JButton("Xóa");
        JButton btnClear = new JButton("Xóa trắng");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER));
        actions.add(btnAdd); actions.add(btnUpdate); actions.add(btnDelete); actions.add(btnClear);

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Mã SV", "Họ tên", "Ngày sinh", "Giới tính", "Email", "Số điện thoại", "Mã lớp"}, 0
        );
        JTable table = new JTable(model);

        Runnable loadData = () -> {
            try {
                model.setRowCount(0);
                for (Model.SinhVien sv : svDAO.getAll(txtSearch.getText())) {
                    model.addRow(new Object[]{
                        sv.maSV, sv.hoTen, sv.ngaySinh, sv.gioiTinh, sv.email, sv.soDienThoai, sv.maLop
                    });
                }
            } catch (SQLException ex) { showError(ex); }
        };

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int r = table.getSelectedRow();
                if (r >= 0) {
                    txtMaSV.setText(val(model, r, 0));
                    txtHoTen.setText(val(model, r, 1));
                    txtNgaySinh.setText(val(model, r, 2));
                    cbGioiTinh.setSelectedItem(val(model, r, 3));
                    txtEmail.setText(val(model, r, 4));
                    txtSDT.setText(val(model, r, 5));
                    txtMaLop.setText(val(model, r, 6));
                }
            }
        });

        btnSearch.addActionListener(e -> loadData.run());
        btnReload.addActionListener(e -> { txtSearch.setText(""); loadData.run(); });
        btnClear.addActionListener(e -> {
            txtMaSV.setText(""); txtHoTen.setText(""); txtNgaySinh.setText("");
            txtEmail.setText(""); txtSDT.setText(""); txtMaLop.setText("");
        });

        btnAdd.addActionListener(e -> {
            try {
                Model.SinhVien sv = new Model.SinhVien(
                    txtMaSV.getText().trim(), txtHoTen.getText().trim(), txtNgaySinh.getText().trim(),
                    cbGioiTinh.getSelectedItem().toString(), txtEmail.getText().trim(),
                    txtSDT.getText().trim(), txtMaLop.getText().trim()
                );
                if (svDAO.insert(sv)) { showInfo("Thêm sinh viên thành công"); loadData.run(); }
            } catch (SQLException ex) { showError(ex); }
        });

        btnUpdate.addActionListener(e -> {
            try {
                Model.SinhVien sv = new Model.SinhVien(
                    txtMaSV.getText().trim(), txtHoTen.getText().trim(), txtNgaySinh.getText().trim(),
                    cbGioiTinh.getSelectedItem().toString(), txtEmail.getText().trim(),
                    txtSDT.getText().trim(), txtMaLop.getText().trim()
                );
                if (svDAO.update(sv)) { showInfo("Sửa sinh viên thành công"); loadData.run(); }
            } catch (SQLException ex) { showError(ex); }
        });

        btnDelete.addActionListener(e -> {
            try {
                if (svDAO.delete(txtMaSV.getText().trim())) { showInfo("Xóa sinh viên thành công"); loadData.run(); }
            } catch (SQLException ex) { showError(ex); }
        });

        JPanel north = new JPanel(new BorderLayout(6, 6));
        north.add(top, BorderLayout.NORTH);
        north.add(form, BorderLayout.CENTER);
        north.add(actions, BorderLayout.SOUTH);

        panel.add(north, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        loadData.run();
        return panel;
    }

    // ================= TAB MÔN HỌC =================
    private JPanel createMonHocPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JTextField txtSearch = new JTextField(20);
        JButton btnSearch = new JButton("Tìm");
        JButton btnReload = new JButton("Tải lại");
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Tìm môn:")); top.add(txtSearch); top.add(btnSearch); top.add(btnReload);

        JTextField txtMaMH = new JTextField();
        JTextField txtTenMH = new JTextField();
        JTextField txtTinChi = new JTextField();
        JPanel form = new JPanel(new GridLayout(2, 3, 6, 6));
        form.add(new JLabel("Mã MH:")); form.add(new JLabel("Tên MH:")); form.add(new JLabel("Số tín chỉ:"));
        form.add(txtMaMH); form.add(txtTenMH); form.add(txtTinChi);

        JButton btnAdd = new JButton("Thêm");
        JButton btnUpdate = new JButton("Sửa");
        JButton btnDelete = new JButton("Xóa");
        JButton btnClear = new JButton("Xóa trắng");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER));
        actions.add(btnAdd); actions.add(btnUpdate); actions.add(btnDelete); actions.add(btnClear);

        DefaultTableModel model = new DefaultTableModel(new String[]{"Mã MH", "Tên MH", "Số tín chỉ"}, 0);
        JTable table = new JTable(model);

        Runnable loadData = () -> {
            try {
                model.setRowCount(0);
                for (Model.MonHoc mh : mhDAO.getAll(txtSearch.getText())) {
                    model.addRow(new Object[]{mh.maMH, mh.tenMH, mh.soTinChi});
                }
            } catch (SQLException ex) { showError(ex); }
        };

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int r = table.getSelectedRow();
                if (r >= 0) {
                    txtMaMH.setText(val(model, r, 0));
                    txtTenMH.setText(val(model, r, 1));
                    txtTinChi.setText(val(model, r, 2));
                }
            }
        });

        btnSearch.addActionListener(e -> loadData.run());
        btnReload.addActionListener(e -> { txtSearch.setText(""); loadData.run(); });
        btnClear.addActionListener(e -> { txtMaMH.setText(""); txtTenMH.setText(""); txtTinChi.setText(""); });

        btnAdd.addActionListener(e -> {
            try {
                int tc = Integer.parseInt(txtTinChi.getText().trim());
                if (mhDAO.insert(new Model.MonHoc(txtMaMH.getText().trim(), txtTenMH.getText().trim(), tc))) {
                    showInfo("Thêm môn học thành công"); loadData.run();
                }
            } catch (Exception ex) { showError(ex); }
        });

        btnUpdate.addActionListener(e -> {
            try {
                int tc = Integer.parseInt(txtTinChi.getText().trim());
                if (mhDAO.update(new Model.MonHoc(txtMaMH.getText().trim(), txtTenMH.getText().trim(), tc))) {
                    showInfo("Sửa môn học thành công"); loadData.run();
                }
            } catch (Exception ex) { showError(ex); }
        });

        btnDelete.addActionListener(e -> {
            try {
                if (mhDAO.delete(txtMaMH.getText().trim())) {
                    showInfo("Xóa môn học thành công"); loadData.run();
                }
            } catch (SQLException ex) { showError(ex); }
        });

        JPanel north = new JPanel(new BorderLayout(6, 6));
        north.add(top, BorderLayout.NORTH);
        north.add(form, BorderLayout.CENTER);
        north.add(actions, BorderLayout.SOUTH);

        panel.add(north, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        loadData.run();
        return panel;
    }

    // ================= TAB ĐIỂM =================
    private JPanel createDiemPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JTextField txtSearch = new JTextField(20);
        JButton btnSearch = new JButton("Tìm");
        JButton btnReload = new JButton("Tải lại");
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Tìm điểm:")); top.add(txtSearch); top.add(btnSearch); top.add(btnReload);

        JTextField txtMaSV = new JTextField();
        JTextField txtMaMH = new JTextField();
        JTextField txtHocKy = new JTextField();
        JTextField txtDiem = new JTextField();
        JPanel form = new JPanel(new GridLayout(2, 4, 6, 6));
        form.add(new JLabel("Mã SV:")); form.add(txtMaSV);
        form.add(new JLabel("Mã MH:")); form.add(txtMaMH);
        form.add(new JLabel("Học kỳ:")); form.add(txtHocKy);
        form.add(new JLabel("Điểm:")); form.add(txtDiem);

        JButton btnAdd = new JButton("Thêm");
        JButton btnUpdate = new JButton("Sửa");
        JButton btnDelete = new JButton("Xóa");
        JButton btnClear = new JButton("Xóa trắng");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER));
        actions.add(btnAdd); actions.add(btnUpdate); actions.add(btnDelete); actions.add(btnClear);

        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Mã SV", "Mã MH", "Học kỳ", "Điểm"}, 0
        );
        JTable table = new JTable(model);

        Runnable loadData = () -> {
            try {
                model.setRowCount(0);
                for (Model.Diem d : diemDAO.getAll(txtSearch.getText())) {
                    model.addRow(new Object[]{d.maSV, d.maMH, d.hocKy, d.diemSo});
                }
            } catch (SQLException ex) { showError(ex); }
        };

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int r = table.getSelectedRow();
                if (r >= 0) {
                    txtMaSV.setText(val(model, r, 0));
                    txtMaMH.setText(val(model, r, 1));
                    txtHocKy.setText(val(model, r, 2));
                    txtDiem.setText(val(model, r, 3));
                }
            }
        });

        btnSearch.addActionListener(e -> loadData.run());
        btnReload.addActionListener(e -> { txtSearch.setText(""); loadData.run(); });
        btnClear.addActionListener(e -> {
            txtMaSV.setText(""); txtMaMH.setText(""); txtHocKy.setText(""); txtDiem.setText("");
        });

        btnAdd.addActionListener(e -> {
            try {
                double d = Double.parseDouble(txtDiem.getText().trim());
                if (diemDAO.insert(new Model.Diem(
                        txtMaSV.getText().trim(), txtMaMH.getText().trim(), txtHocKy.getText().trim(), d))) {
                    showInfo("Thêm điểm thành công"); loadData.run();
                }
            } catch (Exception ex) { showError(ex); }
        });

        btnUpdate.addActionListener(e -> {
            try {
                double d = Double.parseDouble(txtDiem.getText().trim());
                if (diemDAO.update(new Model.Diem(
                        txtMaSV.getText().trim(), txtMaMH.getText().trim(), txtHocKy.getText().trim(), d))) {
                    showInfo("Sửa điểm thành công"); loadData.run();
                }
            } catch (Exception ex) { showError(ex); }
        });

        btnDelete.addActionListener(e -> {
            try {
                if (diemDAO.delete(txtMaSV.getText().trim(), txtMaMH.getText().trim(), txtHocKy.getText().trim())) {
                    showInfo("Xóa điểm thành công"); loadData.run();
                }
            } catch (SQLException ex) { showError(ex); }
        });

        JPanel north = new JPanel(new BorderLayout(6, 6));
        north.add(top, BorderLayout.NORTH);
        north.add(form, BorderLayout.CENTER);
        north.add(actions, BorderLayout.SOUTH);

        panel.add(north, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        loadData.run();
        return panel;
    }

    private String val(DefaultTableModel m, int row, int col) {
        Object o = m.getValueAt(row, col);
        return o == null ? "" : o.toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}