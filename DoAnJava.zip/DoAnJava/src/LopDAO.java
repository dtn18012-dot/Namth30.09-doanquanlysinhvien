import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LopDAO {
    public List<Model.Lop> getAll(String keyword) throws SQLException {
        List<Model.Lop> list = new ArrayList<>();
        String sql = "SELECT MaLop, TenLop, KhoaHoc, NganhHoc FROM lop "
                   + "WHERE (? = '' OR MaLop LIKE ? OR TenLop LIKE ? OR KhoaHoc LIKE ? OR NganhHoc LIKE ?) "
                   + "ORDER BY MaLop";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String k = keyword == null ? "" : keyword.trim();
            ps.setString(1, k);
            ps.setString(2, "%" + k + "%");
            ps.setString(3, "%" + k + "%");
            ps.setString(4, "%" + k + "%");
            ps.setString(5, "%" + k + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Model.Lop(
                        rs.getString("MaLop"),
                        rs.getString("TenLop"),
                        rs.getString("KhoaHoc"),
                        rs.getString("NganhHoc")
                    ));
                }
            }
        }
        return list;
    }

    public boolean insert(Model.Lop lop) throws SQLException {
        String sql = "INSERT INTO lop(MaLop, TenLop, KhoaHoc, NganhHoc) VALUES(?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lop.maLop);
            ps.setString(2, lop.tenLop);
            ps.setString(3, lop.khoaHoc);
            ps.setString(4, lop.nganhHoc);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(Model.Lop lop) throws SQLException {
        String sql = "UPDATE lop SET TenLop = ?, KhoaHoc = ?, NganhHoc = ? WHERE MaLop = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lop.tenLop);
            ps.setString(2, lop.khoaHoc);
            ps.setString(3, lop.nganhHoc);
            ps.setString(4, lop.maLop);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(String maLop) throws SQLException {
        String sql = "DELETE FROM lop WHERE MaLop = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maLop);
            return ps.executeUpdate() > 0;
        }
    }
}