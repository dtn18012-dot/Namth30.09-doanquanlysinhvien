public class Model {
    public static class Lop {
        public String maLop;
        public String tenLop;
        public String khoaHoc;
        public String nganhHoc;

        public Lop() {}
        public Lop(String maLop, String tenLop, String khoaHoc, String nganhHoc) {
            this.maLop = maLop;
            this.tenLop = tenLop;
            this.khoaHoc = khoaHoc;
            this.nganhHoc = nganhHoc;
        }
    }

    public static class SinhVien {
        public String maSV;
        public String hoTen;
        public String ngaySinh;
        public String gioiTinh;
        public String email;
        public String soDienThoai;
        public String maLop;

        public SinhVien() {}
        public SinhVien(String maSV, String hoTen, String ngaySinh, String gioiTinh,
                        String email, String soDienThoai, String maLop) {
            this.maSV = maSV;
            this.hoTen = hoTen;
            this.ngaySinh = ngaySinh;
            this.gioiTinh = gioiTinh;
            this.email = email;
            this.soDienThoai = soDienThoai;
            this.maLop = maLop;
        }
    }

    public static class MonHoc {
        public String maMH;
        public String tenMH;
        public int soTinChi;

        public MonHoc() {}
        public MonHoc(String maMH, String tenMH, int soTinChi) {
            this.maMH = maMH;
            this.tenMH = tenMH;
            this.soTinChi = soTinChi;
        }
    }

    public static class Diem {
        public String maSV;
        public String maMH;
        public String hocKy;
        public double diemSo;

        public Diem() {}
        public Diem(String maSV, String maMH, String hocKy, double diemSo) {
            this.maSV = maSV;
            this.maMH = maMH;
            this.hocKy = hocKy;
            this.diemSo = diemSo;
        }
    }
}