import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MonHocDAO {
    public List<Model.MonHoc> getAll(String keyword) throws SQLException {
        List<Model.MonHoc> list = new ArrayList<>();
        String sql = "SELECT MaMH, TenMH, SoTinChi FROM mon_hoc "
                   + "WHERE (? = '' OR MaMH LIKE ? OR TenMH LIKE ?) "
                   + "ORDER BY MaMH";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String k = keyword == null ? "" : keyword.trim();
            ps.setString(1, k);
            ps.setString(2, "%" + k + "%");
            ps.setString(3, "%" + k + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Model.MonHoc(
                        rs.getString("MaMH"),
                        rs.getString("TenMH"),
                        rs.getInt("SoTinChi")
                    ));
                }
            }
        }
        return list;
    }

    public boolean insert(Model.MonHoc mh) throws SQLException {
        String sql = "INSERT INTO mon_hoc(MaMH, TenMH, SoTinChi) VALUES(?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, mh.maMH);
            ps.setString(2, mh.tenMH);
            ps.setInt(3, mh.soTinChi);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(Model.MonHoc mh) throws SQLException {
        String sql = "UPDATE mon_hoc SET TenMH = ?, SoTinChi = ? WHERE MaMH = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, mh.tenMH);
            ps.setInt(2, mh.soTinChi);
            ps.setString(3, mh.maMH);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(String maMH) throws SQLException {
        String sql = "DELETE FROM mon_hoc WHERE MaMH = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maMH);
            return ps.executeUpdate() > 0;
        }
    }
}